<template>
  <div>
    <button class="btn btn-outline-primary" @click="$emit('get')">Get Employees</button>
  </div>
</template>

<script>
export default {};
</script>

<style scoped></style>
