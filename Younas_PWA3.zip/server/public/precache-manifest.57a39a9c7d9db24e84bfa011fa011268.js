self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ea1b682e907e4da825ec",
    "url": "/css/app.0241f0ea.css"
  },
  {
    "revision": "754547e2285832094e2b",
    "url": "/css/chunk-vendors.5d3035bc.css"
  },
  {
    "revision": "183434f7da5cfd90317e11dbaa2f88c2",
    "url": "/images/employees.jpg"
  },
  {
    "revision": "183434f7da5cfd90317e11dbaa2f88c2",
    "url": "/img/employees.183434f7.jpg"
  },
  {
    "revision": "4df04e671fd8f741d5979ebb3be9470f",
    "url": "/index.html"
  },
  {
    "revision": "ea1b682e907e4da825ec",
    "url": "/js/app.12f001bc.js"
  },
  {
    "revision": "754547e2285832094e2b",
    "url": "/js/chunk-vendors.a72f7e98.js"
  },
  {
    "revision": "f5f4e3b7714f27fc71f2b674ede66cd1",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "ef9c5ce54484cc4533ea54f8625eb074",
    "url": "/service-worker.js"
  }
]);